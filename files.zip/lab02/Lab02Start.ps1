﻿<# 
.SYNOPSIS 
   This script is used to create a starting point for the Azure ITPRO Camp lab exercises.The script first determines 
   a globally unique name for a storage account that can be used for the lab exercises and then creates a 
   new Azure resource group for use in the lab exercises.   
.DESCRIPTION | USAGE
   The script first attempts to remove any local Azure subscription certificates that might interfere with 
   logging into the subscription. You can ignore any errors, if they appear, before you are prompted to log on 
   to your Azure subscription.

   IMPORTANT: Before running this script, please note that you will be prompted to provide your intiails.
   These intials are used to determine a unique name for the storage account. For storage account names,
   you must use all lower case letters or numbers. No hyphens or other characters are allowed.

   
#> 

$init = Read-Host -Prompt "Please type your initials in lower case, and then press ENTER."

Write-Host "Removing local Azure subscription certificates..."
foreach ($sub in Get-AzureSubscription)
{
    if ($sub.Name)
    {
        Remove-AzureSubscription $sub.Name -Force
    }
}
Write-Host "Signing out of Azure..."
foreach ($acct in Get-AzureAccount)
{
    Remove-AzureAccount $acct.Name -Force
}

# Sign into Azure
Login-AzureRmAccount

# Get the default subscription name and use it in $subname variable
$subname = ""
	foreach ($sub in Get-AzureRMSubscription)
	{
	    if ($sub.IsDefault -eq "True")
	    {
	        $subname = $sub.SubscriptionName
	    }
	}

# Make the default subscription the current subscription.
# If you wish to use a subscription other than the default, replace $subname with the name of the subscription.

Select-AzureRMSubscription -SubscriptionName $subname


$loc = "West US"
$rgname1 = "RG-AZITCAMP-STD"
$rgname2 = "RG-AZITCAMP-PREM"
$deploymentname = "Simple-VM"
$templatefilepath = "C:\LabFiles\..."
$templatefileURI = "https://raw.githubusercontent.com/..."
$parameterfilepath = "C:\LabFiles\..."
$parameterfileURI = "https://raw.githubusercontent.com/..." 



# Use Test-Azure to determine unique name for storage account.	

# DEPRECATED Ensure we are in Service Management mode to run the Test-AzureName cmdlet.
# Switch-AzureMode AzureServiceManagement
 
 $uniquename = $false
 $counter = 0
 while ($uniqueName -eq $false)
	{
	    $counter ++
#	     
        $stdstoreName = "$init" + "stdstore" + "$counter"
	    if (!(Test-AzureName -Storage $stdstoreName))
	       {
	            $uniquename = $true
	        }
         $premstorename = "$init" + "premstore" + "$counter"
         if (!(Test-AzureName -Storage $premstoreName))
	       {
	            $uniquename = $true
	        }
	} 
	
Write-Host ""
Write-Host "Please note and use the following as the names for your standard and premium storage accounts in the subsequent lab exercises:" 
            "`n"
Write-Host  "$stdstorename" -ForegroundColor Black -BackgroundColor Green
            "`n"
Write-host  "$premstorename" -ForegroundColor Black -BackgroundColor Green
            "`n"      

Pause

# DEPRECATED Switch to AzureResource Manager mode.

# Switch-AzureMode AzureResourceManager

# If you are running this script on your own computer and not on the supplied host,
# you consider specifying a location that it is closer to your own physical location.

New-AzureRMResourceGroup -Name $rgname1 -Location $loc
New-AzureRMResourceGroup -Name $rgname2 -Location $loc

# If you want to deploy a local template using this script, add values for the $deploymentname, $templatefilepath, and $parametefilepath
# and uncomment the following line.

# New-AzureRMResourceGroupDeployment -Name $deploymentname -ResourceGroupName $rgname -TemplateParameterFile $paremeterfilepath -TemplateFile $templatefilepath

# If you want to deploy a remote template using this script, add values for the $deploymentname, $templatefileURI, and $parametefileURI
# and uncomment the following line.

# New-AzureRMResourceGroupDeployment -Name $deploymentname -ResourceGroupName $rgname -TemplateParameterUri $parameterfileURI -TemplateUri $templatefileURI
